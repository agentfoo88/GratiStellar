import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../core/accessibility/semantic_helper.dart';
import '../../font_scaling.dart';
import '../../l10n/app_localizations.dart';
import '../../services/onboarding_service.dart';
import 'age_gate_screen.dart';
import 'consent_screen.dart';

/// Display mode for the enhanced splash screen
enum SplashDisplayMode {
  /// Onboarding mode: auto-advance after 5 seconds
  onboarding,

  /// About mode: manual dismiss only
  about,
}

/// Enhanced splash screen with animations and dual-mode behavior
///
/// This screen serves two purposes:
/// 1. Initial onboarding splash - shows on first launch, auto-advances
/// 2. About screen - accessible from drawer, requires manual dismiss
///
/// Features rich animations including pulsing logo, floating particles,
/// and text shimmer effects.
class EnhancedSplashScreen extends StatefulWidget {
  final SplashDisplayMode displayMode;

  /// Optional callback called when splash completes (timer expires or tap)
  /// If null, uses default navigation logic for onboarding mode
  final VoidCallback? onComplete;

  const EnhancedSplashScreen({
    super.key,
    this.displayMode = SplashDisplayMode.onboarding,
    this.onComplete,
  });

  @override
  State<EnhancedSplashScreen> createState() => _EnhancedSplashScreenState();
}

class _EnhancedSplashScreenState extends State<EnhancedSplashScreen>
    with TickerProviderStateMixin {
  // Animation controllers
  late AnimationController _fadeController;
  late AnimationController _pulseController;
  late AnimationController _particleController;
  late AnimationController _shimmerController;

  // Animations
  late Animation<double> _fadeAnimation;
  late Animation<double> _pulseAnimation;

  // Particle positions (generated in initState)
  List<ParticleData> _particles = [];

  // Auto-advance timer (onboarding mode only)
  Timer? _autoAdvanceTimer;

  // Navigation flag to prevent double-navigation
  bool _isNavigating = false;

  final OnboardingService _onboardingService = OnboardingService();

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _generateParticles();

    if (widget.displayMode == SplashDisplayMode.onboarding) {
      _startAutoAdvanceTimer();
    }
  }

  /// Set up all animation controllers and animations
  void _setupAnimations() {
    // Main fade-in (1 second, once)
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeIn,
    );

    // Logo pulse (2 seconds, repeat)
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(
        parent: _pulseController,
        curve: Curves.easeInOut,
      ),
    );

    // Particle drift (20 seconds, repeat)
    _particleController = AnimationController(
      duration: const Duration(seconds: 20),
      vsync: this,
    )..repeat();

    // Shimmer effect (3 seconds, repeat)
    _shimmerController = AnimationController(
      duration: const Duration(milliseconds: 3000),
      vsync: this,
    )..repeat();

    // Start fade-in
    _fadeController.forward();
  }

  /// Generate random particle positions and properties
  void _generateParticles() {
    final random = Random();
    _particles = List.generate(10, (index) {
      return ParticleData(
        x: random.nextDouble(),
        y: random.nextDouble(),
        size: 2 + random.nextDouble() * 3,
        speed: 0.3 + random.nextDouble() * 0.4,
        opacity: 0.3 + random.nextDouble() * 0.3,
      );
    });
  }

  /// Start auto-advance timer for onboarding mode
  void _startAutoAdvanceTimer() {
    _autoAdvanceTimer = Timer(const Duration(seconds: 10), () {
      if (!mounted) return;
      _completeSplash();
    });
  }

  /// Handle tap gesture
  void _handleTap() {
    if (_isNavigating) return;

    if (widget.displayMode == SplashDisplayMode.onboarding) {
      _autoAdvanceTimer?.cancel();
      _completeSplash();
    } else {
      // About mode - just pop
      _isNavigating = true;
      Navigator.of(context).pop();
    }
  }

  /// Complete the splash screen (called by timer or tap)
  void _completeSplash() {
    if (_isNavigating) return;
    _isNavigating = true;

    if (widget.onComplete != null) {
      // Use provided callback (for regular app launches)
      widget.onComplete!();
    } else {
      // Default behavior: navigate based on onboarding state
      _navigateNext();
    }
  }

  /// Navigate to next screen based on onboarding state
  Future<void> _navigateNext() async {
    if (_isNavigating) return;
    _isNavigating = true;

    final ageGatePassed = await _onboardingService.hasPassedAgeGate();

    if (!mounted) return;

    if (ageGatePassed) {
      // Age gate already passed, go to consent screen
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const ConsentScreen()),
      );
    } else {
      // First time, show age gate
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const AgeGateScreen()),
      );
    }
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _pulseController.dispose();
    _particleController.dispose();
    _shimmerController.dispose();
    _autoAdvanceTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      body: GestureDetector(
        onTap: _handleTap,
        behavior: HitTestBehavior.opaque,
        child: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFF4A6FA5),
                Color(0xFF166088),
                Color(0xFF0B1426),
                Color(0xFF2C3E50),
              ],
            ),
          ),
          child: SafeArea(
            child: Stack(
              children: [
                // Floating particles layer (decorative)
                SemanticHelper.decorative(
                  child: _buildParticles(),
                ),

                // Main content
                FadeTransition(
                  opacity: _fadeAnimation,
                  child: _buildMainContent(l10n),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Build floating particles layer
  Widget _buildParticles() {
    return AnimatedBuilder(
      animation: _particleController,
      builder: (context, child) {
        return CustomPaint(
          painter: ParticlePainter(
            particles: _particles,
            progress: _particleController.value,
          ),
          size: Size.infinite,
        );
      },
    );
  }

  /// Build main content layout
  Widget _buildMainContent(AppLocalizations l10n) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Spacer(flex: 2),

          // Pulsing logo
          ScaleTransition(
            scale: _pulseAnimation,
            child: SemanticHelper.label(
              label: l10n.appTitle,
              child: SvgPicture.asset(
                'assets/icon_star.svg',
                width: FontScaling.getResponsiveIconSize(context, 180),
                height: FontScaling.getResponsiveIconSize(context, 180),
                colorFilter: const ColorFilter.mode(
                  Color(0xFFFFE135),
                  BlendMode.srcIn,
                ),
              ),
            ),
          ),

          SizedBox(height: FontScaling.getResponsiveSpacing(context, 32)),

          // App title with shimmer
          _buildShimmerText(
            l10n.appTitle,
            FontScaling.getAppTitle(context),
          ),

          SizedBox(height: FontScaling.getResponsiveSpacing(context, 12)),

          // Subtitle
          Text(
            l10n.appSubtitle,
            style: FontScaling.getSubtitle(context),
            textAlign: TextAlign.center,
          ),

          SizedBox(height: FontScaling.getResponsiveSpacing(context, 24)),

          // Divider
          Container(
            width: FontScaling.getResponsiveIconSize(context, 100),
            height: 1,
            color: Colors.white.withValues(alpha: 0.3),
          ),

          SizedBox(height: FontScaling.getResponsiveSpacing(context, 24)),

          // Tagline
          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: FontScaling.getResponsiveSpacing(context, 40),
            ),
            child: Text(
              l10n.appTagline,
              style: FontScaling.getBodyMedium(context).copyWith(
                fontSize: FontScaling.getBodyMedium(context).fontSize! * 0.9,
                fontStyle: FontStyle.italic,
                color: Colors.white.withValues(alpha: 0.9),
              ),
              textAlign: TextAlign.center,
            ),
          ),

          const Spacer(flex: 1),

          // Version info
          FutureBuilder<PackageInfo>(
            future: PackageInfo.fromPlatform(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const SizedBox.shrink();
              final info = snapshot.data!;
              return Text(
                l10n.version(info.version, info.buildNumber),
                style: FontScaling.getCaption(context).copyWith(
                  color: Colors.white.withValues(alpha: 0.5),
                ),
              );
            },
          ),

          SizedBox(height: FontScaling.getResponsiveSpacing(context, 16)),

          // Mode-specific content
          if (widget.displayMode == SplashDisplayMode.about) ...[
            Text(
              l10n.createdBy('AgentFoo88'),
              style: FontScaling.getCaption(context).copyWith(
                color: Colors.white.withValues(alpha: 0.7),
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: FontScaling.getResponsiveSpacing(context, 8)),
          ],

          // Hint text with pulsing opacity
          SemanticHelper.label(
            label: widget.displayMode == SplashDisplayMode.onboarding
                ? l10n.tapToContinue
                : l10n.tapToDismiss,
            isButton: true,
            child: AnimatedBuilder(
              animation: _shimmerController,
              builder: (context, child) {
                return Opacity(
                  opacity: 0.4 + (0.3 * _shimmerController.value),
                  child: Text(
                    widget.displayMode == SplashDisplayMode.onboarding
                        ? l10n.tapToContinue
                        : l10n.tapToDismiss,
                    style: FontScaling.getCaption(context).copyWith(
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  ),
                );
              },
            ),
          ),

          SizedBox(height: FontScaling.getResponsiveSpacing(context, 32)),
        ],
      ),
    );
  }

  /// Build text with shimmer effect
  Widget _buildShimmerText(String text, TextStyle style) {
    return AnimatedBuilder(
      animation: _shimmerController,
      builder: (context, child) {
        return ShaderMask(
          shaderCallback: (bounds) {
            return LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: const [
                Color(0xFFFFE135),
                Color(0xFFFFFFFF),
                Color(0xFFFFE135),
              ],
              stops: [
                (_shimmerController.value - 0.3).clamp(0.0, 1.0),
                _shimmerController.value,
                (_shimmerController.value + 0.3).clamp(0.0, 1.0),
              ],
            ).createShader(bounds);
          },
          child: Text(
            text,
            style: style.copyWith(color: Colors.white),
            textAlign: TextAlign.center,
          ),
        );
      },
    );
  }
}

/// Data class for particle properties
class ParticleData {
  final double x;
  final double y;
  final double size;
  final double speed;
  final double opacity;

  ParticleData({
    required this.x,
    required this.y,
    required this.size,
    required this.speed,
    required this.opacity,
  });
}

/// Custom painter for rendering floating particles
class ParticlePainter extends CustomPainter {
  final List<ParticleData> particles;
  final double progress;

  ParticlePainter({
    required this.particles,
    required this.progress,
  });

  @override
  void paint(Canvas canvas, Size size) {
    for (final particle in particles) {
      final paint = Paint()
        ..color = Color(0xFFFFE135).withValues(alpha: particle.opacity)
        ..style = PaintingStyle.fill;

      // Calculate drifting position (vertical scroll)
      final offsetY = ((progress * particle.speed) % 1.0) * size.height;
      final x = particle.x * size.width;
      final y = (particle.y * size.height + offsetY) % size.height;

      canvas.drawCircle(
        Offset(x, y),
        particle.size,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(ParticlePainter oldDelegate) => true;
}
